CREATE FUNCTION func_plan_type(plan_id BIGINT, task_id BIGINT)
  RETURNS VARCHAR(10)
  BEGIN
    DECLARE union_id BIGINT(20);
    DECLARE task_type VARCHAR(10);
    IF task_id IS NULL
    THEN
      SET union_id = plan_id;
    ELSE
      SET union_id = task_id;
    END IF;

    SELECT type
    INTO task_type
    FROM nw_plan_union
    WHERE id = union_id;
    RETURN task_type;
  END;
