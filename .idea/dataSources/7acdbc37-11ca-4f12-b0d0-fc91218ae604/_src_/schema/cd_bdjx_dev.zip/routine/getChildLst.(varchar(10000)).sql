CREATE FUNCTION getChildLst(rootId VARCHAR(10000))
  RETURNS TEXT
  BEGIN
    DECLARE sTemp TEXT;
    DECLARE sTempChd TEXT;
    SET sTemp = '$';
    SET sTempChd = CAST(rootId AS CHAR);
    WHILE sTempChd IS NOT NULL DO
      SET sTemp = CONCAT(sTemp, ',', sTempChd);
      SELECT GROUP_CONCAT(id)
      INTO sTempChd
      FROM k_department
      WHERE FIND_IN_SET(pid, sTempChd) > 0;
    END WHILE;
    RETURN sTemp;
  END;
