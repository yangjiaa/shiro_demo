CREATE FUNCTION ksi_distance(lat0 DOUBLE, lng0 DOUBLE, lat1 DOUBLE, lng1 DOUBLE)
  RETURNS DOUBLE
  BEGIN
    DECLARE rtn DOUBLE;
    DECLARE c DOUBLE;
    DECLARE D DOUBLE;
    DECLARE R DOUBLE;

    SET D = PI() / 180;
    SET R = 6370.99681;
    SET c = SIN(lat0 * D) * SIN(lat1 * D) + COS(lat0 * D) * COS(lat1 * D) * COS((lng0 - lng1) * D);
    SET rtn = R * ACOS(C);
    RETURN rtn;
  END;
