CREATE VIEW bdz_or_line AS
  SELECT
    `cd_bdjx_dev`.`e_bdz`.`bdz_id`     AS `id`,
    `cd_bdjx_dev`.`e_bdz`.`bdz_name`   AS `name`,
    'bdz'                              AS `type`,
    `cd_bdjx_dev`.`e_bdz`.`dept_id`    AS `dept_id`,
    `cd_bdjx_dev`.`e_bdz`.`voltage_id` AS `voltage_id`,
    `cd_bdjx_dev`.`e_bdz`.`bdz_pinyin` AS `name_pinyin`
  FROM `cd_bdjx_dev`.`e_bdz`
  WHERE (`cd_bdjx_dev`.`e_bdz`.`enabled` = 0)
  UNION ALL SELECT
              `cd_bdjx_dev`.`e_line`.`line_id`     AS `id`,
              `cd_bdjx_dev`.`e_line`.`line_name`   AS `name`,
              'line'                               AS `type`,
              `cd_bdjx_dev`.`e_line`.`dept_id`     AS `dept_id`,
              `cd_bdjx_dev`.`e_line`.`voltage_id`  AS `voltage_id`,
              `cd_bdjx_dev`.`e_line`.`line_pinyin` AS `name_pinyin`
            FROM `cd_bdjx_dev`.`e_line`
            WHERE (`cd_bdjx_dev`.`e_line`.`enabled` = 0)
  ORDER BY `type`, `name`;
